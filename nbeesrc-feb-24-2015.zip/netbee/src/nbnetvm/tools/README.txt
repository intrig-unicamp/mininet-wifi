The folders contained in the "nbnetvm/tools" directory contain the source code 
of three additional tools used during the compilation of nbnetvm. 
Once built, the tools can be found in the nbnetvm/tools/bin directory.
A short explaination of their purpose and usage can be found in each folder.
