#include "counters.h"


u_int32_t n_pkt_check=0;
u_int32_t n_info_check=0;
u_int32_t n_data_check=0;
u_int32_t n_copro_check=0;
u_int32_t n_stack_check=0;
u_int32_t n_initedmem_check=0;
u_int32_t n_jump_check=0;
u_int32_t n_instruction=0;
