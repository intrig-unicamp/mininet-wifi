/*****************************************************************************/
/*                                                                           */
/* Copyright notice: please read file license.txt in the NetBee root folder. */
/*                                                                           */
/*****************************************************************************/




/*
	This file is here only to avoid compilation errors for scanner.c with VS .NET
*/

#ifndef UNISTD_H_INCLUDED
#define UNISTD_H_INCLUDED

#ifndef WIN32
#include <unistd.h>
#endif

#endif
